# Retail Demand Intelligence — MLOps End to End

Projeto de portfólio para previsão de demanda e reposição de estoque no varejo omnichannel. Ele demonstra uma implementação completa em Azure Databricks, do dado bruto ao monitoramento do modelo, sem usar dados ou identidade de qualquer empresa real.

![Dashboard Retail Demand Intelligence](docs/assets/retail-demand-dashboard.png)

## Resultado de negócio

- previsão de demanda diária por `store_id` e `sku_id` para os próximos 7 dias;
- recomendação de reposição considerando estoque, lead time e estoque de segurança;
- redução simulada de ruptura, excesso de estoque e erro de previsão;
- inferência batch e online com trilha de auditoria.

## Arquitetura

```mermaid
flowchart TD
  A[ERP / E-commerce / POS] --> B[Data Factory / Event Hubs]
  B --> C[ADLS Gen2 - Bronze]
  C --> D[Databricks - Silver]
  D --> E[Delta Gold + Feature Tables]
  E --> F[Training + MLflow 3]
  F --> G[Unity Catalog Model Registry]
  G --> H[Batch Scoring]
  G --> I[Model Serving API]
  H --> J[Power BI / Reposição]
  I --> K[Aplicações]
  H --> L[Lakehouse Monitoring]
  I --> L
  L --> M[Alertas + Retraining]
```

## Stack

| Camada | Tecnologias |
|---|---|
| Ingestão | Azure Data Factory, Event Hubs, Auto Loader |
| Dados | ADLS Gen2, Delta Lake, Medallion Architecture |
| Governança | Unity Catalog, Key Vault, Managed Identity |
| Feature engineering | Databricks Feature Engineering, point-in-time joins |
| ML | Python, PySpark, scikit-learn, LightGBM, Hyperopt |
| MLOps | MLflow 3, Model Registry, aliases Champion/Challenger |
| Serving | Databricks Model Serving, FastAPI (modo local) |
| Qualidade | pytest, Ruff, Great Expectations-style checks |
| IaC e CI/CD | Terraform, Databricks Asset Bundles, GitHub Actions, Azure DevOps |
| Observabilidade | inference tables, drift/quality jobs, Azure Monitor |

## Estrutura

```text
src/retail_mlops/       código testável e API local
notebooks/              pipeline Databricks 00–06
resources/              jobs e targets do Asset Bundle
infra/                  infraestrutura Azure em Terraform
deploy/                 imagem Docker da API local
tests/                  testes unitários e de contrato
docs/                   arquitetura, operação e publicação
configs/                parâmetros por ambiente
```

## Executar localmente

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e '.[dev]'
python scripts/generate_data.py --rows 5000
python -m retail_mlops.train --input data/sample/sales.csv --output artifacts
uvicorn retail_mlops.api:app --reload
pytest -q
```

Exemplo de requisição:

```bash
curl -X POST http://localhost:8000/predict \
  -H 'Content-Type: application/json' \
  -d '{"store_id":"S001","sku_id":"SKU001","price":79.9,"discount":0.1,"inventory":42,"day_of_week":2,"month":9,"lag_7":18,"rolling_mean_28":20.4}'
```

## Implantar no Azure Databricks

1. Provisione os recursos com `infra/` e configure secrets fora do Git.
2. Autentique o Databricks CLI com OAuth.
3. Valide e publique o bundle:

```bash
databricks bundle validate -t dev
databricks bundle deploy -t dev
databricks bundle run retail_demand_pipeline -t dev
```

4. Promova somente o modelo aprovado: o job compara o candidato ao Champion e exige melhoria mínima de RMSE, testes de dados e ausência de regressão crítica.

## Segurança e custos

- nenhum segredo é versionado; use Key Vault, managed identities e workload identity federation;
- dados fictícios e sem PII;
- cluster de job com autoscaling e autotermination;
- targets `dev`, `staging` e `prod` isolados;
- `terraform plan` obrigatório antes de qualquer aplicação.

## Métricas

- modelo: RMSE, MAE, WAPE e bias;
- negócio: taxa de ruptura, cobertura, excesso e venda perdida estimada;
- operação: latência p95, erros, freshness, drift PSI e distribuição das previsões.

Leia [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md), [docs/RUNBOOK.md](docs/RUNBOOK.md) e [docs/LINKEDIN_POST.md](docs/LINKEDIN_POST.md).

## Licença

MIT. Projeto educacional com dados sintéticos.
