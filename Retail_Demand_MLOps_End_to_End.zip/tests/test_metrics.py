from retail_mlops.metrics import bias, wape


def test_metrics():
    assert wape([10, 20], [10, 10]) == 1 / 3
    assert bias([10, 20], [10, 10]) == -5
