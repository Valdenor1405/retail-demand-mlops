from fastapi.testclient import TestClient

from retail_mlops.api import app


def test_health():
    assert TestClient(app).get("/health").json() == {"status": "ok"}


def test_validation():
    response = TestClient(app).post("/predict", json={"price": -1})
    assert response.status_code == 422
