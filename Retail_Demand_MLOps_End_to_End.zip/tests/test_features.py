import pandas as pd
import pytest

from retail_mlops.features import FEATURES, feature_matrix, validate_frame


def valid_frame():
    return pd.DataFrame([{**{x: 1 for x in FEATURES}, "discount": 0.1, "units_sold": 3}])


def test_feature_contract():
    frame = valid_frame()
    validate_frame(frame)
    assert list(feature_matrix(frame).columns) == FEATURES


def test_rejects_invalid_discount():
    frame = valid_frame()
    frame["discount"] = 2
    with pytest.raises(ValueError, match="discount"):
        validate_frame(frame)
