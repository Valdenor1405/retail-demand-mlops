# Runbook operacional

## Pipeline falhou

1. Identifique a primeira task com falha e preserve o run id.
2. Confira credenciais, acesso ao volume, schema inesperado e capacidade do cluster.
3. Corrija a causa e reexecute apenas a task/reparo; checkpoints tornam a ingestão idempotente.
4. Se o SLA for ameaçado, mantenha a previsão Champion anterior e avise o consumidor.

## Drift crítico

1. Valide se houve promoção, feriado, fechamento de loja ou mudança de preço.
2. Compare PSI por feature e WAPE segmentado.
3. Se houver degradação real, bloqueie promoção automática e execute retraining.
4. Só promova após validação temporal e de negócio.

## Rollback

1. Localize a última versão saudável no Model Registry.
2. Mova o alias `Champion` para ela.
3. Valide o endpoint e um lote canário.
4. Registre incidente, impacto e ação preventiva.

## Segurança

Revogue credenciais expostas, gire secrets no Key Vault, revise logs e use federação OIDC no CI/CD. Não coloque tokens no Git ou em notebooks.
