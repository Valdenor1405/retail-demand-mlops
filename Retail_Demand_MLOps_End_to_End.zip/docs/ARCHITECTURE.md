# Arquitetura e decisões

## Caso de uso

O sistema agrega vendas omnichannel por dia, loja e SKU, cria variáveis temporais sem vazamento de alvo e prevê unidades vendidas. A previsão alimenta uma recomendação simples de reposição. O dataset é integralmente sintético.

## Fluxo de dados

1. **Ingestão:** Data Factory atende cargas batch; Event Hubs atende eventos; Auto Loader aplica ingestão incremental e evolução de schema.
2. **Bronze:** payload original, metadados de ingestão e retenção para replay.
3. **Silver:** deduplicação, tipos, regras de qualidade, quarentena e cálculo de receita líquida.
4. **Gold:** granularidade diária e tabelas de features no Unity Catalog.
5. **Treinamento:** split temporal, tracking automático, assinatura, exemplo de entrada e métricas no MLflow.
6. **Registro:** modelo versionado no Unity Catalog; aliases `Champion` e `Challenger` evitam acoplamento a números de versão.
7. **Entrega:** batch scoring para planejamento e Model Serving para cenários online.
8. **Monitoramento:** qualidade/freshness, erro real quando o rótulo chega, drift, latência e falhas.

## Controles de produção

- separação de ambientes e catálogos;
- identidade gerenciada e RBAC; secrets nunca no repositório;
- point-in-time correctness para features temporais;
- promoção condicionada a testes e ganho mínimo;
- rollback movendo o alias `Champion` para uma versão anterior;
- aprovação manual na environment `prod` do provedor de CI/CD;
- auditoria e lineage por Unity Catalog.

## Escolha do modelo

Gradient boosting foi escolhido como baseline forte e econômico para dados tabulares. Em evolução, compare LightGBM, XGBoost, Prophet e modelos hierárquicos. A seleção deve considerar WAPE por categoria/loja, estabilidade e custo, não apenas RMSE global.

## SLOs sugeridos

| Indicador | Meta |
|---|---:|
| Pipeline diário concluído | até 06:00 BRT |
| Freshness dos dados | < 24 h |
| Disponibilidade online | 99,5% |
| Latência p95 | < 300 ms |
| WAPE global | < 35% |
| Rollback | < 30 min |
