# Databricks notebook source
import mlflow

env = dbutils.widgets.get("environment")
catalog = f"retail_{env}"
model_name = f"{catalog}.demand.demand_forecaster"
version = dbutils.jobs.taskValues.get(taskKey="train", key="model_version")
client = mlflow.MlflowClient()
candidate = client.get_model_version(model_name, version)
run = client.get_run(candidate.run_id)
candidate_rmse = run.data.metrics["test_rmse"]
try:
    champion = client.get_model_version_by_alias(model_name, "Champion")
    champion_rmse = client.get_run(champion.run_id).data.metrics["test_rmse"]
except Exception:
    champion_rmse = float("inf")
if candidate_rmse <= champion_rmse * 0.98:
    client.set_registered_model_alias(model_name, "Champion", version)
else:
    client.set_registered_model_alias(model_name, "Challenger", version)
assert candidate_rmse < 15.0, f"Quality gate failed: RMSE={candidate_rmse:.3f}"
