# Databricks notebook source
from pyspark.sql import functions as F

env = dbutils.widgets.get("environment")
catalog = f"retail_{env}"
source = spark.table(f"{catalog}.demand.bronze_sales")
clean = (source.dropDuplicates(["transaction_id"])
         .withColumn("event_date", F.to_date("event_timestamp"))
         .filter((F.col("quantity") >= 0) & (F.col("price") > 0))
         .withColumn("net_revenue", F.col("quantity") * F.col("price") * (1 - F.col("discount"))))
bad = source.join(clean.select("transaction_id"), "transaction_id", "left_anti")
clean.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(f"{catalog}.demand.silver_sales")
bad.write.mode("overwrite").saveAsTable(f"{catalog}.demand.quarantine_sales")
assert clean.filter(F.col("store_id").isNull() | F.col("sku_id").isNull()).count() == 0
