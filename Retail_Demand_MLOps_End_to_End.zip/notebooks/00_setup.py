# Databricks notebook source
dbutils.widgets.text("environment", "dev")
ENV = dbutils.widgets.get("environment")
CATALOG = f"retail_{ENV}"
SCHEMA = "demand"
spark.sql(f"CREATE CATALOG IF NOT EXISTS {CATALOG}")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{SCHEMA}")
spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")
