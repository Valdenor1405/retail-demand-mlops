# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql.window import Window

env = dbutils.widgets.get("environment")
catalog = f"retail_{env}"
daily = (spark.table(f"{catalog}.demand.silver_sales")
         .groupBy("event_date", "store_id", "sku_id")
         .agg(F.sum("quantity").alias("units_sold"), F.avg("price").alias("price"),
              F.max("discount").alias("discount"), F.max("inventory").alias("inventory")))
w = Window.partitionBy("store_id", "sku_id").orderBy(F.col("event_date").cast("long"))
features = (daily.withColumn("day_of_week", F.dayofweek("event_date") - 1)
            .withColumn("month", F.month("event_date"))
            .withColumn("lag_7", F.lag("units_sold", 7).over(w))
            .withColumn("rolling_mean_28", F.avg("units_sold").over(w.rowsBetween(-28, -1)))
            .dropna())
features.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(f"{catalog}.demand.demand_features")
spark.sql(f"ALTER TABLE {catalog}.demand.demand_features ADD CONSTRAINT demand_pk PRIMARY KEY(event_date, store_id, sku_id) TIMESERIES NOT ENFORCED")
