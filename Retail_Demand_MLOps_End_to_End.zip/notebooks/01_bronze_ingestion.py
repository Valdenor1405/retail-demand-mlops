# Databricks notebook source
dbutils.widgets.text("environment", "dev")
env = dbutils.widgets.get("environment")
catalog = f"retail_{env}"
source = f"/Volumes/{catalog}/demand/landing/sales"
checkpoint = f"/Volumes/{catalog}/demand/checkpoints/sales"

(spark.readStream.format("cloudFiles")
 .option("cloudFiles.format", "json")
 .option("cloudFiles.schemaLocation", f"{checkpoint}/schema")
 .load(source)
 .withColumn("_ingested_at", __import__("pyspark").sql.functions.current_timestamp())
 .writeStream.option("checkpointLocation", checkpoint)
 .trigger(availableNow=True)
 .toTable(f"{catalog}.demand.bronze_sales"))
