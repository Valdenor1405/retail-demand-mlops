# Databricks notebook source
import mlflow
from mlflow.models import infer_signature
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_squared_error

env = dbutils.widgets.get("environment")
catalog = f"retail_{env}"
model_name = f"{catalog}.demand.demand_forecaster"
pdf = spark.table(f"{catalog}.demand.demand_features").orderBy("event_date").toPandas()
features = ["price", "discount", "inventory", "day_of_week", "month", "lag_7", "rolling_mean_28"]
split = int(len(pdf) * .8)
train, test = pdf.iloc[:split], pdf.iloc[split:]
mlflow.set_registry_uri("databricks-uc")
mlflow.sklearn.autolog(log_models=False)
with mlflow.start_run(run_name=f"demand-{env}") as run:
    model = HistGradientBoostingRegressor(max_iter=250, random_state=42).fit(train[features], train.units_sold)
    pred = model.predict(test[features]).clip(min=0)
    rmse = mean_squared_error(test.units_sold, pred) ** .5
    mlflow.log_metric("test_rmse", rmse)
    info = mlflow.sklearn.log_model(model, name="model", signature=infer_signature(test[features], pred), input_example=test[features].head(3))
    version = mlflow.register_model(info.model_uri, model_name)
dbutils.jobs.taskValues.set("model_version", version.version)
