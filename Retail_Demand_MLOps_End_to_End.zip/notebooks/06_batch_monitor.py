# Databricks notebook source
import mlflow
from pyspark.sql import functions as F

env = dbutils.widgets.get("environment")
catalog = f"retail_{env}"
model_uri = f"models:/{catalog}.demand.demand_forecaster@Champion"
predict_udf = mlflow.pyfunc.spark_udf(spark, model_uri, result_type="double")
features = spark.table(f"{catalog}.demand.demand_features")
scored = (features.withColumn("prediction", F.greatest(F.lit(0.0), predict_udf(F.struct(*[F.col(c) for c in ["price","discount","inventory","day_of_week","month","lag_7","rolling_mean_28"]]))))
          .withColumn("scored_at", F.current_timestamp()))
scored.write.mode("append").saveAsTable(f"{catalog}.demand.demand_predictions")
stats = scored.agg(F.avg(F.abs(F.col("units_sold") - F.col("prediction"))).alias("mae"), F.count("*").alias("rows"))
stats.withColumn("measured_at", F.current_timestamp()).write.mode("append").saveAsTable(f"{catalog}.demand.model_monitoring")
