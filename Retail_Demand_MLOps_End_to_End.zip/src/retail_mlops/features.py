from __future__ import annotations

import pandas as pd

FEATURES = [
    "price",
    "discount",
    "inventory",
    "day_of_week",
    "month",
    "lag_7",
    "rolling_mean_28",
]
TARGET = "units_sold"


def validate_frame(df: pd.DataFrame, training: bool = True) -> None:
    required = set(FEATURES + ([TARGET] if training else []))
    missing = sorted(required - set(df.columns))
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    if df[list(required)].isna().any().any():
        raise ValueError("Null values found in required columns")
    if (df["price"] <= 0).any():
        raise ValueError("price must be positive")
    if not df["discount"].between(0, 1).all():
        raise ValueError("discount must be between 0 and 1")


def feature_matrix(df: pd.DataFrame) -> pd.DataFrame:
    validate_frame(df, training=False)
    return df[FEATURES].astype(float)
