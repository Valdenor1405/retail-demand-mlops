from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import mlflow
import mlflow.sklearn
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error

from retail_mlops.features import FEATURES, TARGET, feature_matrix, validate_frame
from retail_mlops.metrics import bias, wape


def train(input_path: str, output_dir: str) -> dict[str, float]:
    df = pd.read_csv(input_path, parse_dates=["date"]).sort_values("date")
    validate_frame(df)
    split = max(1, int(len(df) * 0.8))
    train_df, test_df = df.iloc[:split], df.iloc[split:]
    model = HistGradientBoostingRegressor(max_iter=180, learning_rate=0.07, random_state=42)
    model.fit(feature_matrix(train_df), train_df[TARGET])
    pred = model.predict(feature_matrix(test_df)).clip(min=0)
    metrics = {
        "rmse": float(mean_squared_error(test_df[TARGET], pred) ** 0.5),
        "mae": float(mean_absolute_error(test_df[TARGET], pred)),
        "wape": wape(test_df[TARGET], pred),
        "bias": bias(test_df[TARGET], pred),
    }
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, out / "model.joblib")
    (out / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    (out / "feature_contract.json").write_text(json.dumps(FEATURES, indent=2), encoding="utf-8")
    try:
        with mlflow.start_run(run_name="retail-demand-local"):
            mlflow.log_params({"algorithm": "HistGradientBoostingRegressor", "rows": len(df)})
            mlflow.log_metrics(metrics)
            mlflow.sklearn.log_model(model, name="model")
    except Exception:
        pass  # local tracking is optional; artifacts above remain reproducible
    return metrics


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", default="artifacts")
    args = parser.parse_args()
    print(json.dumps(train(args.input, args.output), indent=2))


if __name__ == "__main__":
    main()
