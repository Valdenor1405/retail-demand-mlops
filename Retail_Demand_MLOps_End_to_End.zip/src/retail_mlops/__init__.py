"""Retail demand MLOps package."""

__version__ = "1.0.0"
