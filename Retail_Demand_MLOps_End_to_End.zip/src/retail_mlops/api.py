from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from retail_mlops.features import FEATURES, feature_matrix

app = FastAPI(title="Retail Demand Forecast API", version="1.0.0")


class DemandRequest(BaseModel):
    store_id: str
    sku_id: str
    price: float = Field(gt=0)
    discount: float = Field(ge=0, le=1)
    inventory: float = Field(ge=0)
    day_of_week: int = Field(ge=0, le=6)
    month: int = Field(ge=1, le=12)
    lag_7: float = Field(ge=0)
    rolling_mean_28: float = Field(ge=0)


@lru_cache
def load_model():
    path = Path(os.getenv("MODEL_PATH", "artifacts/model.joblib"))
    if not path.exists():
        raise FileNotFoundError(f"Model not found at {path}")
    return joblib.load(path)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/predict")
def predict(request: DemandRequest) -> dict[str, float | str]:
    try:
        row = pd.DataFrame([{name: getattr(request, name) for name in FEATURES}])
        forecast = max(0.0, float(load_model().predict(feature_matrix(row))[0]))
        reorder = max(0.0, forecast * 7 - request.inventory)
        return {
            "store_id": request.store_id,
            "sku_id": request.sku_id,
            "daily_demand": round(forecast, 2),
            "suggested_reorder_qty": round(reorder, 0),
        }
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
