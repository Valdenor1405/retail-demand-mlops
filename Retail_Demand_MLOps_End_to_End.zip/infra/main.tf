terraform {
  required_version = ">= 1.7"
  required_providers {
    azurerm = { source = "hashicorp/azurerm", version = "~> 4.0" }
    databricks = { source = "databricks/databricks", version = "~> 1.60" }
  }
  backend "azurerm" {}
}

provider "azurerm" { features {} }

variable "project" { type = string; default = "retailmlops" }
variable "environment" { type = string; default = "dev" }
variable "location" { type = string; default = "brazilsouth" }

locals { name = "${var.project}-${var.environment}" }

resource "azurerm_resource_group" "this" { name = "rg-${local.name}"; location = var.location }
resource "azurerm_storage_account" "lake" {
  name = substr(replace("st${local.name}", "-", ""), 0, 24)
  resource_group_name = azurerm_resource_group.this.name
  location = azurerm_resource_group.this.location
  account_tier = "Standard"
  account_replication_type = "LRS"
  is_hns_enabled = true
  min_tls_version = "TLS1_2"
  allow_nested_items_to_be_public = false
}
resource "azurerm_storage_data_lake_gen2_filesystem" "lake" { name = "lakehouse"; storage_account_id = azurerm_storage_account.lake.id }
resource "azurerm_key_vault" "this" {
  name = substr("kv-${local.name}", 0, 24)
  location = azurerm_resource_group.this.location
  resource_group_name = azurerm_resource_group.this.name
  tenant_id = data.azurerm_client_config.current.tenant_id
  sku_name = "standard"
  enable_rbac_authorization = true
  purge_protection_enabled = true
}
data "azurerm_client_config" "current" {}
resource "azurerm_log_analytics_workspace" "this" { name = "log-${local.name}"; location = azurerm_resource_group.this.location; resource_group_name = azurerm_resource_group.this.name; retention_in_days = 30 }
resource "azurerm_databricks_workspace" "this" {
  name = "dbw-${local.name}"
  resource_group_name = azurerm_resource_group.this.name
  location = azurerm_resource_group.this.location
  sku = "premium"
  managed_resource_group_name = "rg-${local.name}-managed"
}

output "databricks_workspace_url" { value = azurerm_databricks_workspace.this.workspace_url }
output "storage_account_name" { value = azurerm_storage_account.lake.name }
