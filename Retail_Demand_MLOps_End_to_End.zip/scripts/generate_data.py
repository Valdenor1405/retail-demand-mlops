from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def generate(rows: int, output: str, seed: int = 42) -> None:
    rng = np.random.default_rng(seed)
    dates = pd.date_range("2024-01-01", periods=max(100, rows // 20), freq="D")
    date = rng.choice(dates, rows)
    dow = pd.DatetimeIndex(date).dayofweek
    month = pd.DatetimeIndex(date).month
    price = rng.uniform(20, 500, rows).round(2)
    discount = rng.choice([0, 0.05, 0.1, 0.2, 0.3], rows, p=[0.55, 0.1, 0.18, 0.12, 0.05])
    lag_7 = rng.gamma(4, 5, rows)
    rolling = np.maximum(0, lag_7 + rng.normal(0, 3, rows))
    season = np.where(np.isin(month, [5, 11, 12]), 1.25, 1.0)
    demand = np.maximum(
        0,
        rolling * season * (1 + 1.8 * discount) * (1.1 - price / 1500)
        + rng.normal(0, 3, rows),
    )
    df = pd.DataFrame({
        "date": date,
        "store_id": [f"S{x:03d}" for x in rng.integers(1, 31, rows)],
        "sku_id": [f"SKU{x:04d}" for x in rng.integers(1, 401, rows)],
        "price": price,
        "discount": discount,
        "inventory": rng.integers(0, 150, rows),
        "day_of_week": dow,
        "month": month,
        "lag_7": lag_7.round(2),
        "rolling_mean_28": rolling.round(2),
        "units_sold": demand.round().astype(int),
    }).sort_values("date")
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--rows", type=int, default=5000)
    parser.add_argument("--output", default="data/sample/sales.csv")
    args = parser.parse_args()
    generate(args.rows, args.output)
